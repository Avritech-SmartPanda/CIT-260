package Week01;

public class Main {

    public static void main(String[] args) {
	// write your code here
        System.out.println("Daphne Avril Museruka");
        System.out.println("CIT260-04");
        System.out.println("Mutare, Zimbabwe");
        System.out.println("Carrot cake");
    }
}
